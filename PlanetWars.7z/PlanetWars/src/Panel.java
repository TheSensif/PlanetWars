
interface Panel
{
	public final int SCREEN_WIDTH = 1024;
	public final int SCREEN_HEIGHT = 768;
}