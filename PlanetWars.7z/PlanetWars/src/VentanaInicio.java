import javax.swing.*;
import java.awt.*;

interface Panel
{
	public final int SCREEN_WIDTH = 1024;
	public final int SCREEN_HEIGHT = 768;
}


public class VentanaInicio extends JFrame implements Panel{
	private JTabbedPane panel1, panel2;
    public VentanaInicio() {
        JPanel frame = new JPanel();

        add(frame);

        this.setTitle("Planet Wars");
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);

        this.setSize(SCREEN_WIDTH,SCREEN_HEIGHT);
        this.setResizable(false);

        Toolkit pantalla = Toolkit.getDefaultToolkit();

        Dimension grandaria = pantalla.getScreenSize();
        int ancho = grandaria.width;
        int alto = grandaria.height;

        this.setLocation((ancho/2) - (this.getWidth() / 2), (alto / 2) - (this.getHeight() / 2));

        Image imagen = pantalla.getImage("./src/Planet Wars.png");

        this.setIconImage(imagen);

        
    }
}
