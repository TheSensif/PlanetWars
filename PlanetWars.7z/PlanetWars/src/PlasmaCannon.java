
public class PlasmaCannon extends Defense{

	public PlasmaCannon(int armor, int baseDamage) {
		super(armor, baseDamage);
	}
}