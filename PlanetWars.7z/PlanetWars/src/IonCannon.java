
public class IonCannon extends Defense{

	public IonCannon(int armor, int baseDamage) {
		super(armor, baseDamage);
	}
}