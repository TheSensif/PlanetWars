
public class PlanetWars {
    public static void main(String[] args) {
        VentanaInicio vi = new VentanaInicio();
    }
}
