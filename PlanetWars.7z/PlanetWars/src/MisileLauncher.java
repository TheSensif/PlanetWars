
public class MisileLauncher extends Defense{

	public MisileLauncher(int armor, int baseDamage) {
		super(armor, baseDamage);
	}
	
}
