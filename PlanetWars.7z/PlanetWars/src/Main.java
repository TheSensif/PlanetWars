import java.awt.BorderLayout;
import java.awt.Dimension;
import java.util.Timer;
import java.util.TimerTask;
import javax.swing.*;
import java.awt.*;
import javax.swing.Box;
import javax.swing.JMenu;
import javax.swing.JMenuBar;

public class Main extends JFrame{
	
    public Main() {
        JMenuBar menu = new JMenuBar();

        JMenu ViewPlanetStats = new JMenu("<html><p style='text-align:center;width:150px;'>View Planet Stats</p></html>");
        JMenu Build = new JMenu("<html><p style='text-align:center;width:150px;'>Build");
        JMenu UpgradeTecnology = new JMenu("<html><p style='text-align:center;width:150px;'>Upgrade Technology");
        JMenu ViewBattleReports = new JMenu("<html><p style='text-align:center;width:150px;'>View Battle Reports");
        JMenu Exit = new JMenu("<html><p style='text-align:center;width:150px;'>Exit");
	
        JMenuItem BuildDefense = new JMenuItem("<html><p style='text-align:center;width:140px;'>Defense");
        JMenuItem BuildShips = new JMenuItem("<html><p style='text-align:center;width:140px;'>Ships");
        
        Build.add(BuildShips);
        Build.add(BuildDefense);
        
        menu.add(ViewPlanetStats);
        menu.add(Build);
        menu.add(UpgradeTecnology);
        menu.add(ViewBattleReports);
        menu.add(Exit);

        add(menu, BorderLayout.NORTH);
        menu.add(Box.createRigidArea(new Dimension(20,50)));
        //menu.setMargin(new Insets(0,50,0,50));

        this.setTitle("Planet Wars");
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);

        this.setSize(1024,768);
        this.setResizable(false);
        this.setVisible(true);
    }
	
	public static void main(String[] args) {
		Main m = new Main();
		Planet p = new Planet();
		Timer timer = new Timer();
		TimerTask resourcesGeneration = new TimerTask() {
			public void run()
			{
				System.out.println("The resources has been generated");
				p.setMetal(p.getMetal() + 200);
				p.setDeuterium(p.getDeuterium() + 10);
				System.out.println("Actual metal -> " + p.getMetal());
				System.out.println("Actual deuterium -> " + p.getDeuterium());
			}
		};
		
		
		timer.schedule(resourcesGeneration, 5000, 5000); 
	}
}
