
public class MisileLauncher extends Defense{
	@Override
	public String toString() {
		return "Missile Launcher";
	}
	public MisileLauncher(int armor, int baseDamage) {
		super(armor, baseDamage);
	}
	
}
