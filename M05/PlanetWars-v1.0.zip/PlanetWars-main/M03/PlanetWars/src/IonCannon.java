
public class IonCannon extends Defense{
	@Override
	public String toString() {
		return "Ion Cannon";
	}
	public IonCannon(int armor, int baseDamage) {
		super(armor, baseDamage);
	}
}