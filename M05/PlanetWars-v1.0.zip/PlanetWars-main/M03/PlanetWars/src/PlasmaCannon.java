
public class PlasmaCannon extends Defense{
	@Override
	public String toString() {
		return "Plasma Cannon";
	}
	public PlasmaCannon(int armor, int baseDamage) {
		super(armor, baseDamage);
	}
}